﻿#include <iostream>
#include <vector>
#include <opencv.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/xfeatures2d.hpp>

using namespace std;
using namespace cv;
using namespace cv::xfeatures2d;

int main()
{
	//read image
	Mat img1 = imread("../data/book.png");
	Mat img2 = imread("../data/book_in_scene.png");

	//user controll
	int nfeatures = 0;
	int OctaveLayer = 5;

	Ptr<SIFT> sift = SIFT::create(nfeatures, OctaveLayer);

	//detect keypoints
	vector<KeyPoint>keypoints1, keypoints2;
	sift->detect(img1, keypoints1);
	sift->detect(img2, keypoints2);

	//compute descriptors
	Mat descriptors1, descriptors2;
	sift->compute(img1, keypoints1, descriptors1);
	sift->compute(img2, keypoints2, descriptors2);

	//match between image1's points and image2's points
	FlannBasedMatcher matcher;
	vector<DMatch>dmatches;
	matcher.match(descriptors1, descriptors2, dmatches);

	double max_dist = 0;double min_dist = 100;

	//compute min_distance and max_distance
	for(int i = 0;i <descriptors1.rows;i++)
	{
		double dist = dmatches[i].distance;
		if(dist<min_dist)min_dist = dist;
		if(dist>max_dist)max_dist = dist;
	}


	//find good feature
	std::vector<DMatch>good_matches;
	for(int i = 0;i <descriptors1.rows;i++)
	{
		if(dmatches[i].distance <max(2 * min_dist, 0.02))
		{
			good_matches.push_back(dmatches[i]);
		}
	}

	//put vector for drawing circle on image
	vector<vector<Point2f>> matches;
	for(int i = 0;i<good_matches.size();i++)
	{
		vector<Point2f> match;
		match.push_back(keypoints1[good_matches[i].queryIdx].pt);
		match.push_back(keypoints2[good_matches[i].trainIdx].pt);
		matches.push_back(match);
	}

	//image = image1 + image2 (concatenate images)
	Mat img =Mat::zeros(max(img1.rows, img2.rows), img1.cols + img2.cols, CV_8UC3);

	for(int i = 0;i<img1.rows;++i)
	{
		for(int j = 0;j<img1.cols;++j)
		{
			img.at<Vec3b>(i, j) = img1.at<Vec3b>(i, j);
		}
	}

	for (int i  = 0;i<img2.rows;++i)
	{
		for(int j = 0;j<img2.cols;++j)
		{
			img.at<Vec3b>(i, j + img1.cols) = img2.at<Vec3b>(i, j);
		}
	}

	//drow circle about points
	for(int i = 0;i<matches.size();++i)
	{
		Scalar color(rand() % 256, rand() % 256, rand() % 256);
		circle(img, matches[i][0], 5, color, -1);
		circle(img, Point(matches[i][1].x + img1.cols, matches[i][1].y), 5, color, -1);
	}


	//draw matching points with line
	Mat dst;
	drawMatches(img1, keypoints1, img2, keypoints2,
		good_matches, dst, Scalar::all(-1), Scalar::all(-1),
		vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);


	imshow("img1", img1);
	imshow("img2", img2);
	imshow("1", img);
	imshow("2", dst);

	waitKey(0);
	return 0;
}





