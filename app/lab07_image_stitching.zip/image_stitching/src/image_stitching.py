# -*- coding: utf-8 -*-
"""
Created on Fri Nov 16 09:40:22 2018

@author: Jaewon
"""

import numpy as np
import cv2

def get_homography(img1, img2):
    # a parameter for SURF
    minHessian = 100
    
    surf = cv2.xfeatures2d.SURF_create(minHessian)
    # detect keypoints from img1 and img2
    kp1 = surf.detect(img1)
    kp2 = surf.detect(img2)
    # describe keypoints from img1 and img2
    des1 = surf.compute(img1, kp1)
    des2 = surf.compute(img2, kp2)
    # match the keypoints     
    flann = cv2.FlannBasedMatcher()
    matches = np.array(flann.match(des1[-1], des2[-1]))
    matches = np.reshape(matches, (-1))
    # store the matching points to data structure used by findHomography    
    src_pts = np.float32([ kp1[m.queryIdx].pt for m in matches]).reshape(-1,1,2)
    dst_pts = np.float32([ kp2[m.trainIdx].pt for m in matches]).reshape(-1,1,2)
    # find the homography from src_pts to dst_pts
    H, _= cv2.findHomography(src_pts, dst_pts, cv2.RANSAC)
    
    return H

def get_stitched_image(imgs, nimages):
    # convert the color images to their gray images
    img_gray = []
    for i in range(nimages):
        gray = cv2.cvtColor(imgs[i], cv2.COLOR_BGR2GRAY)
        img_gray.append(gray)
        
    H = [np.eye(3, dtype='float64')]
    # compute homographies H[k] from image k-1 to k
    for k in range(1, nimages):
        k1 = k - 1
        H_temp = get_homography(img_gray[k1], img_gray[k])
        H.append(H_temp)
    
    # compute composite homographies compositeH[k] from 0 to k
	# compute icomposite homographies icompositeH[k] from k to 0
    compositeH = [np.eye(3, dtype='float64')]
    icompositeH = [np.eye(3, dtype='float64')]
    
    for k in range(1, nimages):
        k1 = k - 1
        compositeH.append(np.dot(H[k],compositeH[k1]))
        
        icompositeH_temp = np.zeros((3,3))
        cv2.invert(compositeH[k], dst=icompositeH_temp, flags=cv2.DECOMP_SVD)
        icompositeH.append(icompositeH_temp)
    # compute the size of the panoramic image
    min_sx = 0.
    min_sy = 0.
    max_ey, max_ex = img_gray[0].shape
    
    for k in range(1, nimages):
        sx = 0
        sy = 0
        ey, ex = img_gray[k].shape
        
        corners = np.zeros((4,2), dtype='float32')
        corners[0] = [0, 0]
        corners[1] = [ex, 0]
        corners[2] = [ex, ey]
        corners[3] = [0, ey]
        
        tr_corners = cv2.perspectiveTransform(corners.reshape(-1,1,2), icompositeH[k]).reshape(4,2)
        print(corners)
        print(tr_corners)        
        for m in range(4):
            if(tr_corners[m][0] < min_sx):
                min_sx = tr_corners[m][0]
            
            if(tr_corners[m][0] > max_ex):
                max_ex = tr_corners[m][0]
            
            if(tr_corners[m][1] < min_sy):
                min_sy = tr_corners[m][1]
            
            if(tr_corners[m][1] > max_ey):
                max_ey = tr_corners[m][1]
            
    # the panoramic image's coordinate frame is dx and dy shifted from the image frame of img[0]
	# x'=x+dx, y'=y+dy
    dx = int(-min_sx + 0.5)    
    dy = int(-min_sy + 0.5)

    width = int(max_ex + 0.5) + dx
    height = int(max_ey + 0.5) + dy
    # panoramic image    
    panorama = np.zeros((height, width, 3), dtype='uint8')
    # if any value has been copied to a pixel in the panoramic image the flag is 1, otherwise the flag is 0.
    flag = np.zeros((height, width), dtype=np.float32)
    #  copy img[0] to the panoramic image
    for y in range(imgs[0].shape[0]):
        for x in range(imgs[0].shape[1]):
            panorama[y + dy, x + dx] = imgs[0][y, x]
            flag[y + dy, x + dx] = 1
    # the coordinates of the panoramic image is transformed to img[0] first.
    corners = []
    for y in range(height):
        for x in range(width):
            corners.append((float(x - dx), float(y - dy)))
    
    corners = np.array(corners)
    # transform a point in the panoramic image to img[k], and copy the corresponding pixels color to the point by using bilinear interpolation.
    for k in range(1, nimages):
        rows, cols, _ = imgs[k].shape
        tr_corners = cv2.perspectiveTransform(corners.reshape(-1,1,2), compositeH[k]).reshape(-1,2)

        m = 0
        for y in range(height):
            for x in range(width):
                m += 1
                if(flag[y, x] == 1):
                    continue
                
                fx = float(tr_corners[m - 1][0])
                fy = float(tr_corners[m - 1][1])
                x0 = int(np.floor(fx))
                y0 = int(np.floor(fy))
                x1 = int(np.ceil(fx))
                y1 = int(np.ceil(fy))
                
                if(x0 >= 0 and x1 < cols and y0 >= 0 and y1 < rows):
                    cx0 = float(x1 - fx)
                    cx1 = float(fx - x0)
                    cy0 = float(y1 - fy)
                    cy1 = float(fy - y0)
                    
                    r = np.uint8(max(min(cx0 * (cy0 * imgs[k][y0, x0][2] + cy1 * imgs[k][y1, x0][2]) + cx1 * (cy0 * imgs[k][y0, x1][2] + cy1 * imgs[k][y1, x1][2]), 255.), 0.) + 0.5)
                    g = np.uint8(max(min(cx0 * (cy0 * imgs[k][y0, x0][1] + cy1 * imgs[k][y1, x0][1]) + cx1 * (cy0 * imgs[k][y0, x1][1] + cy1 * imgs[k][y1, x1][1]), 255.), 0.) + 0.5)
                    b = np.uint8(max(min(cx0 * (cy0 * imgs[k][y0, x0][0] + cy1 * imgs[k][y1, x0][0]) + cx1 * (cy0 * imgs[k][y0, x1][0] + cy1 * imgs[k][y1, x1][0]), 255.), 0.) + 0.5)
                
                    panorama[y, x] = (b, g, r)
                    flag[y, x] = 1
                
    return panorama

if __name__ == "__main__":
    # number of images to be loaded
	# you can decrease the number of images if you cannot stitch all 9 images together	
    nimages = 3
    # load images and convert the color images to their gray images    
    imgs = []
    for i in range(nimages):
        fname = "../data/songdo{0:02d}.jpg".format(i)
        imgs.append(cv2.imread(fname))
        
    panorama = get_stitched_image(imgs, nimages)
        
    cv2.imwrite("../result/result_python.jpg", panorama)
    
    
    